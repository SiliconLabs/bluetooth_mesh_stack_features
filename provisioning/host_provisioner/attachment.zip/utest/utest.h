/*************************************************************************
    > File Name: utest.h
    > Author: Kevin
    > Created Time: 2019-03-21
    >Description: 
 ************************************************************************/

#ifndef UTEST_H
#define UTEST_H

void utestAll(int enable, int end);
#endif

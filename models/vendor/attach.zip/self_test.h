/*************************************************************************
    > File Name: self_test.h
    > Author: Kevin
    > Created Time: 2018-10-18
    >Description: 
 ************************************************************************/

#ifndef SELF_TEST_H
#define SELF_TEST_H

#define SERVER_PUB_ADDR 				0xD254
#define SERVER_SUB_ADDR 				0xE320

#endif
